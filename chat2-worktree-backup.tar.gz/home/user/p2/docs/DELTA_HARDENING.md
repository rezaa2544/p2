# Delta Sync Hardening — فاز ۲ (گزارش کامل)

- **برنچ:** `feat/delta-hardening-phase2` · **تاریخ:** ۲۰۲۶-۰۹-۱۱ (تهران)
- **مرجع مأموریت:** SKILLS_MASTER (انطباق معماری/امنیت/تست) + بریف «Delta Sync Hardening Phase 2»
- **روش:** پیاده‌سازی + گیت‌های واقعی + **اجرای زنده روی PostgreSQL واقعی** (embedded-postgres خارج از ریپو، پورت ۵۵۴۳۲) با فیکسچرِ دقیقاً **۹۲۳٬۲۹۲ ردیف** — هیچ عددی از حدس نیست؛ خروجی خام در همین سند.

---

## ۰) صداقتِ محیطی (مقایسهٔ بریف با واقعیت ریپو)

| ادعای بریف | واقعیت | اقدام این فاز |
|---|---|---|
| `docs/SERVER_CLIENT_CONTRACT.md` موجود است | **موجود نبود** | **ایجاد شد** (این فاز) — قرارداد سیمِ pull/sync + Cursor TTL |
| `docs/DELTA_COVERAGE_REPORT_2026-09-11.md` | موجود نبود | محتوایش در همین سند آمد |
| تست‌های `wave4-sync-all-collections` / `wave10-query-audit` / `contract-layers` | **موجود نبودند** (معادل‌ها: `wave4-sync.js` ۱۱/۱۱، `wave10-db-scale.js` ۲۶/۲۶) | هر سه به‌عنوان سوئیت‌های واقعی ساخته شدند: ‏۱۳/۱۳، ‏۱۴/۱۴، ‏۱۸/۱۸ — تعدادشان نتیجهٔ پوشش واقعی است، نه هدفِ از پیش تعیین‌شده |
| «cursor فعلی امضاشده ولی ثابت است» | در این ریپو کرسرِ دلتا `since` خامِ **بدون امضا** بود (کرسرهای REST هم `date|id` ساده) | ماژول `server/cursor.js` ساخته شد: امضا + TTL + تمدید |
| PG 16 | بستهٔ `embedded-postgres@18.4.0-beta.17` فقط **PostgreSQL 18.4** می‌دهد (همان که Wave 3 هم استفاده کرد) | اجرا روی ۱۸.۴ — قید صریح |
| migrations 001-010 | زنجیرهٔ واقعی: **001-004** (+ دو ۰۰۴ هم‌شماره) | این فاز `005_delta_sync_updated_at_indexes` را افزود |
| فیکسچر ۹۲۳٬۲۹۲ ردیف | ساخته شد — **دقیقاً ۹۲۳٬۲۹۲** (شمارش دقیق SQL، نه تخمین) | جدول §۳ |

---

## ۱) شکاف ۱ — دلتای کهنه (۷+ روز) → اسنپ‌شات کامل

**ریشهٔ مشکل:** پنجرهٔ دلتای `since` بی‌کران است؛ کلاینتِ ۷+ روز آفلاین، دلتایی به‌اندازهٔ کل تغییراتِ دوره می‌گیرد و correctness آن به نگهداریِ تومب‌استون در کل دوره وابسته است.

**طراحی (fail-safe برای کلاینت قدیمی):**
- `server/pull.js`: اگر `since` کهنه‌تر از `PAYESH_DELTA_MAX_AGE_DAYS` (پیش‌فرض ۷) باشد → پاسخ، **خودِ اسنپ‌شات کامل** است + `full_snapshot_required: true` + `full_snapshot_reason: 'since_too_old'`.
- **تومب‌استون‌های بعد از `since` همچنان برمی‌گردند** — کلاینتِ قدیمیِ بی‌آگاه از پرچم هم حذفیاتِ آن هفته را اعمال می‌کند (جمع‌شدگی تضمینی).
- آستانه per-request از env خوانده می‌شود (بدون ری‌استارت قابل تنظیم/آزمون).
- کلاینت (`src/js/29-pull.js`): در اسنپ‌شاتِ کامل، مجموعه‌های بازگشتی **جایگزین** می‌شوند (نه merge) — ردیفِ غایبِ سرور حذف می‌شود؛ فقط ردیف‌های صفِ آفلاین (`pendingSet`) محفوظ می‌مانند. دلتا عینِ قبل merge است.
- `server_time`/`next_cursor` از **لحظهٔ شروعِ خواندن** بریده می‌شود (نه پایان پاسخ) — ردیف‌هایی که وسطِ pull تغییر کنند در دلتای بعدی گم نمی‌شوند (اصلاح یک باگِ مرزیِ از پیش موجود).

**شاهد:** ‏`tests/delta-sync-hardening.js` DH1–DH4 + DH14 · `tests/wave4-sync-all-collections.js` AC3/AC4/AC11.

## ۲) شکاف ۲ — کرسرِ امضاشده با TTL (۱ ساعت) + تمدید خودکار

**ریشهٔ مشکل:** `since` ادعای آزادِ کلاینت بود — هر مقداری پذیرفته می‌شد (جعل/replay بی‌هزینه).

**طراحی — `server/cursor.js` (بدون وابستگی، فقط stdlib):**
- توکن: `pc1.<b64url(payload)>.<b64url(HMAC-SHA256)>` با payload ‏`{v:1, since, iat, exp, jti}`.
- کلید: `PAYESH_CURSOR_SECRET` (≥۳۲ بایت) وگرنه اشتقاقِ domain-separated از `PAYESH_JWT_SECRET`/کلید JWT فایلی — **کلیدِ کرسر هرگز برابرِ کلیدِ JWT نیست**. بدون کلید: کرسر **غیرفعال** (fail-closed؛ `since`legacy سالم می‌ماند).
- TTL پیش‌فرض **۳۶۰۰s** (۱ ساعت)، clamp ‏۶۰..۸۶۴۰۰ (`PAYESH_CURSOR_TTL_S`).
- راستی‌آزمایی: امضا با مقایسهٔ constant-time؛ `iat` آینده (>۵min skew) رد؛ `exp` گذشته → `cursor_expired`.
- سرور (`pull.js`): `?cursor=` را verify می‌کند — منقضی/نامعتبر ⇒ **401** با کدِ متمایز + `cursor_renewal:'full_pull'`. `sinceِ` داخلِ توکنِ امضاشده بر `?since=` ادعایی **مقدم** است. هر پاسخِ موفق `next_cursor` تازه (۱ ساعت اعتبار) + `cursor_ttl_s` دارد.
- کلاینت: توکن را ذخیره می‌کند و به‌جای `since` می‌فرستد (فقط توکنِ سالم‌شکلِ `pc1.`؛ رشتهٔ `"null"` ممکن نیست ارسال شود)؛ روی 401 ⇒ **یک** pull کامل (تمدید، بدون حلقه) و ذخیرهٔ کرسرِ تازه.
- سازگاری: کلاینتِ قدیمیِ فقط-`since` رفتارِ قبلِ فاز ۲ را عیناً می‌گیرد (DH17)؛ کلیدهای تازه روی سیم **افزودنی‌اند**.

**شاهد:** ‏`tests/delta-sync-hardening.js` DH5–DH13 · `tests/contract-layers.js` CL9–CL13 · `tests/wave4-sync-all-collections.js` AC12.

## ۳) شکاف ۳ — دلتا زیر بار (ابزار + اجرای زنده)

**ابزار:** `tools/delta-load-test.js`
- **DRY_RUN پیش‌فرض** (بدون DB؛ خروجی صریحاً «شبیه‌سازی — سنجهٔ عملکرد نیست»)؛ `--live` با `DATABASE_URL`.
- `--live`: N درخواست (پیش‌فرض ۱۰۰۰) با هم‌زمانی C از **builderهای واقعی تولید** (`syncdelta.deltaRowsSql`) با bind واقعی؛ گزارش p50/p95/p99/max، throughput، نرخ خطا (تفکیکِ «خطای سخت» از «شکاف اسکیما → fallback شفاف pull.js»)، و pool metrics (total/idle/waiting با نمونه‌گیری 50ms + اوج‌ها).
- فقط SELECT؛ خروجی JSON با `--out`؛ exit ‏0/1/2 (تنظیم‌پذیر با `--max-error-rate`).

**اجرای زنده — PostgreSQL 18.4 واقعی (پورت ۵۵۴۳۲)، فیکسچر ۹۲۳٬۲۹۲ ردیف:**

| جدول | ردیف | | جدول | ردیف |
|---|---:|---|---|---:|
| grades | ۳۲۳٬۰۰۰ | | leaves | ۲۰٬۰۰۰ |
| attendance | ۳۲۰٬۰۰۰ | | notifications | ۲۰٬۰۰۰ |
| discipline | ۶۰٬۰۰۰ | | hw_submissions | ۲۰٬۰۰۰ |
| users | ۴۵٬۰۰۰ | | counselor_msgs | ۲۰٬۰۰۰ |
| schedule | ۴۲٬۰۰۰ | | announcements | ۵٬۰۰۰ |
| enrollments | ۴۲٬۰۰۰ | | classes / bell_schedules / counselor_refs | ۲٬۰۰۰+۲٬۰۰۰+۲٬۰۰۰ |
| | | | subjects ‏/ schools / sync_conflicts | ‏۱۲۰ / ۱۰ / ۱۶۲ |

- ۱٪ ردیف‌ها تازه (۲ دقیقه پیش — پنجرهٔ دلتای زنده)، ۹۹٪ کهنه (۳۰ روز) — سناریوی «روزِ فعال مدرسه».
- ۱۷ جدول از ۱۹ مجموعهٔ pull — `homework` و `vclass_rooms` **در زنجیرهٔ migrations وجود ندارند** (زنجیره `hw_assignments` را مدل کرده؛ `vclass_rooms` هیچ معادلی ندارد)؛ سهمشان (۲۳٬۰۰۰) به grades واگذار شد تا **مجموع دقیقاً ۹۲۳٬۲۹۲** بماند.
- `sync_conflicts` ستون `updated_at` **ندارد** → در pull زندهٔ PG هرسه به‌صورت شفاف full-read می‌شوند (رفتارِ امنِ از پیش طراحی‌شدهٔ pull.js؛ در ابزار جدا شمرده می‌شوند).

**یافتهٔ عملکردی (P0 این فاز): هیچ ایندکسی روی `updated_at` نبود** — در حالی که نصفِ پرادیکتِ دلتا و کلِ ORDER BY روی آن است. `EXPLAIN` روی grades قبل از اصلاح: Parallel Seq Scan، ‏**37.4ms**، ‏~۱۰۶٬۵۹۰ ردیف فیلترشده. → **migrations/005** شانزده ایندکس `updated_at` ساخت.

**A/B واقعی (۱۰۰۰ درخواست، هم‌زمانی کامل ۱۰۰۰، pool max=20):**

| سنجه | قبل از 005 (Seq Scan) | بعد از 005 (BitmapOr) | بهبود |
|---|---:|---:|---:|
| p50 | ۴٬۰۴۸ ms | **۴۷۲ ms** | ~۸.۶× |
| p95 | ۵٬۰۰۹ ms | **۸۱۵ ms** | ~۶.۱× |
| p99 | ۵٬۰۴۴ ms | **۸۵۰ ms** | ~۵.۹× |
| max | ۵٬۱۵۰ ms | **۸۵۶ ms** | ~۶.۰× |
| throughput | ‏۱۹۴ req/s | **۱٬۱۵۷ req/s** | ~۶.۰× |
| wall | ‏۵.۱۶ s | ‏۰.۸۶ s | ~۶.۰× |
| pool: اوجِ waiting | ‏۹۷۹ | ‏۹۶۷ | (گلوگاهِ صفِ اتصال، طبیعی در burst=۱۰۰۰) |
| خطای سخت | ‏۰ | ‏۰ | — |

مرجعِ هم‌زمانیِ پایدارتر (بعد از 005، ‏c=100): ‏p50=**۸۶ms** · p95=۱۰۷ms · p99=۱۲۸ms · ‏**۱٬۱۳۱ req/s** · اوجِ waiting=۸۰.

`EXPLAIN` بعد از 005 (همان کوئری): Bitmap Heap Scan + BitmapOr روی `idx_grades_created_at` ∪ `idx_grades_updated_at` → **0.9ms** (۴۱×) — از builderِ واقعی تولید، نه SQL دست‌نویس.

> قید: سندباکس تک‌نمونه با ۲GB RAM است؛ اعدادِ مطلقِ سخت‌افزارِ تولید نیستند. نسبت‌های A/B و مسیرِ پلن (Seq→BitmapOr) کیفیت‌مند و قابل اتکا هستند.

## ۴) شکاف ۴ — اندازه‌گیری تعارض (دو کلاینت موازی)

- `server/metrics.js`: هیستوگرام تازهٔ **`payesh_sync_conflict_detection_seconds`** (برچسبِ بستهٔ `outcome: conflict|stale|clean`؛ باکت‌های میلی‌ثانیه‌ای) در کنار `payesh_sync_conflicts_total` موجود.
- `server/sync.js`: زمانِ **خودِ تشخیص** (یافتنِ رکورد + مقایسهٔ base_version — پیش از ثبتِ تعارض/اعلان) برای هر نوشتِ نسخه‌دار ثبت می‌شود؛ R1 (رصدپذیری هرگز مسیرِ درخواست را نمی‌شکند) رعایت شده.
- شاهد دو-کلاینتِ موازی: ‏`tests/delta-sync-hardening.js` DH15 — دو مدیرِ هم‌مدرسه هم‌زمان push می‌کنند (A با پایهٔ جاری، ‏B با پایهٔ کهنه) ⇒ دقیقاً یکی `ok` و یکی `conflict_preserved` + سطرِ `sync_conflicts` (هر دو نسخه ثبت) + شمارنده +1. ‏DH16 زمانِ تشخیص برای هر دو مسیرِ conflict/clean را می‌سنجد؛ ‏DH17 حضور در exposition پرومتئوس.

**قیدِ شناخته‌شده (ثبت صادقانه):** دو نوشتِ هم‌پایهٔ کاملاً هم‌زمان در موتورِ حافظه می‌توانند هر دو از دروازه رد شوند (TOCTOU بین گیت و apply؛ آینهٔ PG دومرحله‌ای apply را تراکنشی می‌کند). تستِ DH15 سناریوی قطعی (پایهٔ کهنهٔ B حتی پیش از اعمالِ A تعارض است) را می‌آزماید، نه شانسِ درهم‌تنیدگی. بستنِ این TOCTOU روی موتورِ حافظه = کارِ آیندهٔ «push تک‌تراکنشی» (باقی‌ماندهٔ Wave 1).

## ۵) گیت‌ها (همه سبز — جز یک قرمزِ پیش‌ existing)

| گیت | نتیجه |
|---|---|
| `tests/smoke.js` | **۵۴۷/۵۴۷** ✅ |
| `tests/check-authz.js` | exit **0** ✅ |
| `tests/secret-scan.js` | **۱۱/۱۱** ✅ |
| `node build.js --check` | exit **0** ✅ |
| `tests/wave4-sync.js` | **۱۱/۱۱** ✅ |
| `tests/wave10-db-scale.js` | **۲۶/۲۶** ✅ |
| `tests/delta-sync-hardening.js` (جدید) | **۱۹/۱۹** ✅ |
| `tests/wave4-sync-all-collections.js` (جدید) | **۱۳/۱۳** ✅ |
| `tests/wave10-query-audit.js` (جدید) | **۱۴/۱۴** ✅ |
| `tests/contract-layers.js` (جدید) | **۱۸/۱۸** ✅ |
| رگرسیون: pull-bootstrap / wave1-reads / wave3-query / wave3-query2 / wave14-observability / sync-dup-claim / sync-chunk / sync-atomic-batch | ‏۱۲/۱۲ · ۱۸/۱۸ · ۱۳/۱۳ · ۱۳/۱۳ · ۹۵/۹۵ · ۷/۷ · سبز · ۲۲/۲۲ ✅ |
| `tests/wave3-keyset.js` | **۱۱/۱۳** — قرمزِ **پیش‌موجود**؛ A/B با HEADِ تمیز (`git stash`) همان ۱۱/۱۳ — نامرتبط با این فاز |
| `tests/occ.js` | قرمزِ محیطیِ پیش‌موجود (نبودِ `server/data/payesh.json` در ریپو) — نامرتبط |

## ۶) کارهای باقی‌مانده (صادقانه)

1. ~~**شکاف اسکیما:** جدول‌های `homework`/`vclass_rooms` در زنجیرهٔ migrations نیستند؛ `sync_conflicts` ستون `updated_at` ندارد~~ — **✅ بسته شد در فاز ۳** (شاخهٔ `feat/delta-schema-gaps`، کامیت‌های `2dad76a`/`a5a4226`/`ebd3d4e`؛ جزئیات: §۷ همین سند).
2. ایندکس‌های 005 روی تولید با `CONCURRENTLY` اعمال شوند (قیدِ داخلِ تراکنش — همان سیاستِ 004).
3. بستنِ TOCTOUِ هم‌پایهٔ هم‌زمان روی موتورِ حافظه (وابسته به push تک‌تراکنشی).
4. تومب‌استونِ DB-native (`server_tombstones`) همچنان PENDING (وابسته به write-side زنده).
5. سنجهٔ بار روی سخت‌افزارِ واقعیِ تولید/replica — اعداد این سند از سندباکسِ ۲GB است.

---

## ۷) فاز ۳ — بستن شکاف‌های اسکیما (`feat/delta-schema-gaps`)

**تاریخ:** ۲۰۲۶-۰۹-۱۱ · **بیس:** `feat/delta-hardening-phase2` @ `c13cd3f` · **مهاجرت:** `006_delta_schema_gaps.sql` (+down)

| شکاف | تصمیم فنی | کامیت | شاهد |
|---|---|---|---|
| ۱. `homework` در allowlist، بدون جدول (کلاینت/مدل/zنجیره همه `hw_assignments`) | جایگزینی نامِ مرده با مجموعهٔ واقعی `hw_assignments` (دارای school_id و updated_at) در pull/syncdelta + هر سه آینه | `2dad76a` | `tests/delta-schema-gaps.js` SG1–SG5؛ رگرسیونِ باگِ پنهان: پولِ PG-live قبلاً با `SELECT * FROM "homework"` (42P01) کلِ درخواست را ۵۰۰ می‌کرد |
| ۲. `vclass_rooms` در allowlist، بدون هیچ معادل | **حذف نامِ مرده — جدول ساخته نشد** (صفر مصرف‌کننده؛ جدولِ بی‌خواننده = نویزِ اسکیما). سطحِ واقعیِ vclass یعنی `vclass_sessions` (school_id ⇒ scope) جایگزین شد | `a5a4226` | SG6–SG8 (ساخت کوئری، سرو در پولِ پیش‌فرض، جداسازی مدرسه‌ای)؛ شاهدِ زندهٔ A8: `SELECT * FROM "vclass_rooms"` ⇒ 42P01 — جدول هرگز وجود نداشت |
| ۳. `sync_conflicts` بدون `updated_at` ⇒ دلتا در PG-live خطای 42703 | مهاجرت 006 دقیقاً با SQL بریف (ADD COLUMN → backfill از created_at → SET NOT NULL → ایندکس) + ایندکس‌های `hw_assignments`/`vclass_sessions` + مُهرِ `updated_at` در sync.js (ایجاد) و conflicts.js (داوری) | `ebd3d4e` | SG9–SG12؛ شاهدهای زندهٔ §۷.۳ |

**مرزِ آگاهانه (نه باگ):** `vclass_questions`/`vclass_links`/`vclass_attendance` جدول دارند ولی **school_id ندارند** (فقط session_id/student_id) — افزودن‌شان به پولِ پیش‌فرض یعنی عبورِ همهٔ سطرها از فیلترِ scope به‌عنوانِ «global» و **نشت بین‌مدرسه‌ای**. تا وقتی scope مبتنی بر session→school ساخته نشود، در سطحِ پول نمی‌آیند.

### ۷.۳) شاهدهای زندهٔ PostgreSQL 18.4 (همان خوشهٔ فاز ۲، پورت 55432)

- **زنجیرهٔ تازه 001→006 روی DB خالی:** همهٔ مهاجرت‌ها سبز؛ `updated_at` از ابتدا NOT NULL؛ INSERT بدون updated_at ⇒ 23502 رد؛ با مُهر صریح ⇒ پذیرفته.
- **ارتقای پایگاهِ «تولید» فاز ۲ (162 تعارضِ واقعی، pre-006):** قبل از 006 کوئری دلتا با خطای واقعی `column "updated_at" does not exist` می‌میرد؛ 006 دوبارِ متوالی اعمال شد (توان‌مند)؛ backfill دقیقاً ۱۶۲/۱۶۲ ردیف `updated_at = created_at`، صفر NULL؛ هر سه ایندکس ساخته شد؛ EXPLAIN با `enable_seqscan=off` از `idx_sync_conflicts_updated_at` می‌خواند.
- **دلتای واقعی با builder خودِ ریپو:** ردیفِ تعارضِ کهنه که «حالا» resolve شد (فقط updated_at تازه) دقیقاً خودش در دلتا برمی‌گردد — مسیرِ resolve→delta که بدونِ این ستون هرگز دیده نمی‌شد.
- **برستِ end-to-end با ابزار خودِ ریپو** (`--live -n 60 -c 10` روی سه مجموعهٔ شکاف): **60/60 موفق · خطای سخت 0 · p50=4.15ms · p95=35.16ms · توان 1132 req/s** — pool پیکِ waiting=0.
- خروجی کامل: `node /home/user/.cache/pgtool/verify-006.js` (20/20) و `live-006.json`.
